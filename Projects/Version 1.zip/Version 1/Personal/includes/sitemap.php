<?php
	echo '
		<ul>
			<li><a href="home.php" target="_self">Home</a></li>
			<li>User
				<ul>
					<li><a href="login.php" target="_self">Login</a>
					<li><a href="logout.php" target="_self">Logout</a></li>
				</ul>
			</li>
			<li><a href="refueling.php" target="_self">Refueling</a></li>
			<li>Admin</a>
				<ul>
					<li><a href="Users.php" target="_self">Users</a></li>
					<li><a href="Makers.php" target="_self">Makers</a></li>
					<li><a href="Models.php" target="_self">Models</a></li>
					<li><a href="Gasbrands.php" target="_self">Gas Brands</a></li>
				</ul>
			</li>
		</ul>';
?>
