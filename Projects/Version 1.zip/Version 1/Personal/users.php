<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Untitled Document</title>
</head>

<body>
	<h1>Gas Tracker</h1>
	<h2>This will be the users page.</h2>

	<?php
		include ('includes/sitemap.php');
	?>  
</body>
</html>