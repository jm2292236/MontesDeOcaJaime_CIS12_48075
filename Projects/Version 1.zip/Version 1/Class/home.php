<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Untitled Document</title>
</head>

<body>
	<h1>Royal Prestige - Cooking your Health</h1>
	<h2>This will be the home page.</h2>

	<?php
		include ('includes/sitemap.php');
	?>  
</body>
</html>