<?php
	echo '
		<ul>
			<li><a href="home.php" target="_self">Home</a></li>
			<li>Products</a>
				<ul>
					<li><a href="catalog.php" target="_self">Catalog</a></li>
				</ul>
			</li>
			<li>Shopping Cart</a>
				<ul>
					<li><a href="cart.php" target="_self">Cart</a></li>
					<li><a href="checkout.php" target="_self">Checkout</a></li>
					<li><a href="confirmation.php" target="_self">Confirmation</a></li>
				</ul>
			</li>
			<li>User
				<ul>
					<li><a href="login.php" target="_self">Login</a>
					<li><a href="logout.php" target="_self">Logout</a></li>
				</ul>
			</li>
			<li>Admin
				<ul>
					<li><a href="users.php" target="_self">Users</a>
					<li><a href="products.php" target="_self">Products</a></li>
				</ul>
			</li>
		</ul>';
?>