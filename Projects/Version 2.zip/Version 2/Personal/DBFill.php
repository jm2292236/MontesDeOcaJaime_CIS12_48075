<?php
	// Inserts users
	//include ('DBFill_jm2292236_e_user.php');

    // Inserts Gas Brands
	include ('DBFill_jm2292236_enum_gasbrand.php');
	
    // Inserts Makers
	include ('DBFill_jm2292236_enum_maker.php');
	
    // Inserts Makers-Models
	include ('DBFill_jm2292236_enum_maker_model.php');
	
    // Inserts Cars
	include ('DBFill_jm2292236_e_car.php');
	
    // Inserts Gas Refueling
	include ('DBFill_jm2292236_e_refuel.php');
?>
