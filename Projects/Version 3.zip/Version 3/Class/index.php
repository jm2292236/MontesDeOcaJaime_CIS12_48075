<?php # Script 3.4 - index.php
	$page_title = 'Welcome to this Site!';
	include ('./includes/header.html');
?>

<?php
	include ('./includes/footer.html');
?>
